var class_socket =
[
    [ "Socket", "class_socket.html#a7c3256c4fc6e2c603df73201049fae5a", null ],
    [ "~Socket", "class_socket.html#aeac4eb6379a543d38ed88977d3b6630a", null ],
    [ "GetSendWsaBuf", "class_socket.html#a38d7ac9607110011fcd1bcdcef83a628", null ],
    [ "Initialize", "class_socket.html#a91b370b6e31c8005242c1bbdac3733d3", null ],
    [ "ProcessPacket", "class_socket.html#a5ad8812144d8c4024e9050872b97b068", null ],
    [ "ReadPacket", "class_socket.html#adc67e3bcd49667da9b36b8a36c74ed11", null ],
    [ "SendPacket", "class_socket.html#a98b2655dda559d8ca8fbbc5fa6ced808", null ]
];