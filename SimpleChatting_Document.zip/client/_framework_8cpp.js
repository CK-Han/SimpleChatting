var _framework_8cpp =
[
    [ "EditSubProc", "_framework_8cpp.html#a2186e1deba81627ba16e90fac96459e4", null ],
    [ "SplitString", "_framework_8cpp.html#aa12c1894cf36ad0cd01b0b54733f6b54", null ]
];