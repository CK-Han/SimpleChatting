var searchData=
[
  ['editsubproc',['EditSubProc',['../_framework_8cpp.html#a2186e1deba81627ba16e90fac96459e4',1,'Framework.cpp']]]
];
