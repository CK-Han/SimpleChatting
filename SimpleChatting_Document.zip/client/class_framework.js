var class_framework =
[
    [ "GetEditInput", "class_framework.html#a5050140df6c01f8e8610a23e02fdcf42", null ],
    [ "GetOldInputProc", "class_framework.html#a00bc94ed4410c54a0aa51005b31ad647", null ],
    [ "GetUserSocket", "class_framework.html#aa821d2b1bb702a9413ba9f38f82bf7b0", null ],
    [ "ProcessPacket", "class_framework.html#a7bf9a6a5b13598b3d1b472a07cf640be", null ],
    [ "ProcessUserInput", "class_framework.html#a0cbf3222d04939cc8031ddb9d0fad5c9", null ],
    [ "ProcessWindowMessage", "class_framework.html#a07d07cc8d7dba2fdb40984521966f754", null ],
    [ "Run", "class_framework.html#a7c470032410260980a4848fa3d247fec", null ]
];