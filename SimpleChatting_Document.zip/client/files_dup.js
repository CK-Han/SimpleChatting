var files_dup =
[
    [ "Framework.cpp", "_framework_8cpp.html", "_framework_8cpp" ],
    [ "Framework.h", "_framework_8h.html", [
      [ "Framework", "class_framework.html", "class_framework" ]
    ] ],
    [ "main.cpp", "main_8cpp.html", "main_8cpp" ],
    [ "resource.h", "resource_8h.html", null ],
    [ "Socket.cpp", "_socket_8cpp.html", null ],
    [ "Socket.h", "_socket_8h.html", [
      [ "Socket", "class_socket.html", "class_socket" ]
    ] ]
];