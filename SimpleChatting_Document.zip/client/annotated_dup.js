var annotated_dup =
[
    [ "Framework", "class_framework.html", "class_framework" ],
    [ "Socket", "class_socket.html", "class_socket" ]
];