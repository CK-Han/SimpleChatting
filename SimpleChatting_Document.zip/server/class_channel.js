var class_channel =
[
    [ "Channel", "class_channel.html#a6d2d650baccf6debd2b9d4d8814b81c1", null ],
    [ "~Channel", "class_channel.html#a5f15ebd302464069f1a9e3f0ded14482", null ],
    [ "Enter", "class_channel.html#a8037adcd6d33dd6ec5bbd5359b84db0e", null ],
    [ "Exit", "class_channel.html#a54e59f0efd2fbe566f35e4dca6c8e3e7", null ],
    [ "GetChannelLock", "class_channel.html#aa34e2351bd4cd9aad46fe03205f52c71", null ],
    [ "GetChannelMaster", "class_channel.html#a7e95004fdd95f97951e2a2663a9efb4c", null ],
    [ "GetChannelName", "class_channel.html#ad74f875356fba9363e14a727cb241134", null ],
    [ "GetClientsInChannel", "class_channel.html#ac51156fd1396728ed28bce7b60ed851a", null ],
    [ "GetUserCount", "class_channel.html#a030e280257ada64334f49a4118646b99", null ],
    [ "channelLock", "class_channel.html#a5868dcda7efc8214ad81ff8590a36aa5", null ],
    [ "channelMaster", "class_channel.html#a5545a0283fe272dd187fb417c25c6b89", null ],
    [ "channelName", "class_channel.html#a58c51aaec2f50bb2e19f6ee9cf7fe99a", null ],
    [ "clientsInChannel", "class_channel.html#ab06c94af30d1a3d95fccb8bc0b3c5045", null ]
];