var hierarchy =
[
    [ "Channel", "class_channel.html", [
      [ "CustomChannel", "class_custom_channel.html", null ],
      [ "PublicChannel", "class_public_channel.html", null ]
    ] ],
    [ "Client", "struct_client.html", null ],
    [ "Framework", "class_framework.html", null ],
    [ "Overlap_Exp", "struct_overlap___exp.html", null ]
];