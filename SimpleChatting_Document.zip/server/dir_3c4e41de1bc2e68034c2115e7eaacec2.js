var dir_3c4e41de1bc2e68034c2115e7eaacec2 =
[
    [ "Channel.cpp", "_channel_8cpp.html", null ],
    [ "Channel.h", "_channel_8h.html", [
      [ "Channel", "class_channel.html", "class_channel" ],
      [ "PublicChannel", "class_public_channel.html", "class_public_channel" ],
      [ "CustomChannel", "class_custom_channel.html", "class_custom_channel" ]
    ] ],
    [ "Client.h", "_client_8h.html", [
      [ "Overlap_Exp", "struct_overlap___exp.html", "struct_overlap___exp" ],
      [ "Client", "struct_client.html", "struct_client" ]
    ] ],
    [ "Framework.cpp", "_framework_8cpp.html", null ],
    [ "Framework.h", "_framework_8h.html", [
      [ "Framework", "class_framework.html", "class_framework" ]
    ] ],
    [ "main.cpp", "main_8cpp.html", "main_8cpp" ]
];