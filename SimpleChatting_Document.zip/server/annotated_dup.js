var annotated_dup =
[
    [ "Channel", "class_channel.html", "class_channel" ],
    [ "Client", "struct_client.html", "struct_client" ],
    [ "CustomChannel", "class_custom_channel.html", "class_custom_channel" ],
    [ "Framework", "class_framework.html", "class_framework" ],
    [ "Overlap_Exp", "struct_overlap___exp.html", "struct_overlap___exp" ],
    [ "PublicChannel", "class_public_channel.html", "class_public_channel" ]
];