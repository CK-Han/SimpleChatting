var dir_0cdbb5426308061d7474a752d8c27826 =
[
    [ "SimpleChatting", "dir_78d40e0b90ee74289fe0b0f037ebb35c.html", "dir_78d40e0b90ee74289fe0b0f037ebb35c" ]
];