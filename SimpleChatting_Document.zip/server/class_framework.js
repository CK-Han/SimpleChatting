var class_framework =
[
    [ "SERIAL_TYPE", "class_framework.html#a9844c3bb11d2b9717022f48b93079003", null ],
    [ "SERIAL_GET", "class_framework.html#a94a40046c01acaf6f9c1818af7c47455", [
      [ "CLIENT", "class_framework.html#a94a40046c01acaf6f9c1818af7c47455aef10c650df47bffd6399e5e78da2a9b1", null ],
      [ "CUSTOMCHANNEL", "class_framework.html#a94a40046c01acaf6f9c1818af7c47455aeb4bda15400a55d4af659769e861d1ec", null ],
      [ "OVERLAPEXP", "class_framework.html#a94a40046c01acaf6f9c1818af7c47455aedd26aadf6a50ef0721264122b93481b", null ]
    ] ],
    [ "DebugCustomChannels", "class_framework.html#a66c028fb29ccab738e469610db7becd0", null ],
    [ "DebugUserCount", "class_framework.html#a507bdeffb4e6d676e2d7941400d58086", null ],
    [ "GetClient", "class_framework.html#af8abc1b47cac9b216a5d751c4dcf096b", null ],
    [ "GetIocpHandle", "class_framework.html#a81b98b75aebc9b631d1ec337e91d85a6", null ],
    [ "GetSerialForNewOne", "class_framework.html#af1eb7fd0f7fd0edbdb358e9e9ec205a9", null ],
    [ "IsShutDown", "class_framework.html#a256f005736928713897edadaca1f772f", null ],
    [ "IsValidClientSerial", "class_framework.html#a708b6041277ad05ce6b67277953ffc39", null ],
    [ "ProcessPacket", "class_framework.html#a149e0f84f171193ca73f16ff8edd26d9", null ],
    [ "ProcessUserClose", "class_framework.html#a261ae9ac17fdeea17ec08946274e6a1a", null ],
    [ "ReturnUsedOverlapExp", "class_framework.html#aa58d2a9fcf0654d2661dc6e54d6a108e", null ],
    [ "SendPacket", "class_framework.html#a81b3851e56a236921cbf9bb28413e636", null ],
    [ "SendSystemMessage", "class_framework.html#a25f24e6d880b27adb51135186d18c853", null ]
];