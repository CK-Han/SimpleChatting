var files_dup =
[
    [ "SimpleChatting", "dir_0cdbb5426308061d7474a752d8c27826.html", "dir_0cdbb5426308061d7474a752d8c27826" ]
];