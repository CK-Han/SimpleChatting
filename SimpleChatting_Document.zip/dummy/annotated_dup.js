var annotated_dup =
[
    [ "Dummy", "class_dummy.html", "class_dummy" ],
    [ "DummyHandler", "class_dummy_handler.html", "class_dummy_handler" ],
    [ "Event_Compare", "class_event___compare.html", "class_event___compare" ],
    [ "Event_Info", "struct_event___info.html", "struct_event___info" ],
    [ "Overlap_Exp", "struct_overlap___exp.html", "struct_overlap___exp" ],
    [ "Overlap_Info", "struct_overlap___info.html", "struct_overlap___info" ]
];