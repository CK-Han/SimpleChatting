var files_dup =
[
    [ "Dummy.cpp", "_dummy_8cpp.html", null ],
    [ "Dummy.h", "_dummy_8h.html", [
      [ "Dummy", "class_dummy.html", "class_dummy" ]
    ] ],
    [ "DummyHandler.cpp", "_dummy_handler_8cpp.html", null ],
    [ "DummyHandler.h", "_dummy_handler_8h.html", [
      [ "Overlap_Exp", "struct_overlap___exp.html", "struct_overlap___exp" ],
      [ "Overlap_Info", "struct_overlap___info.html", "struct_overlap___info" ],
      [ "Event_Info", "struct_event___info.html", "struct_event___info" ],
      [ "Event_Compare", "class_event___compare.html", "class_event___compare" ],
      [ "DummyHandler", "class_dummy_handler.html", "class_dummy_handler" ]
    ] ],
    [ "main.cpp", "main_8cpp.html", "main_8cpp" ]
];