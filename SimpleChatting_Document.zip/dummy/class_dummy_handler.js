var class_dummy_handler =
[
    [ "Packet_Procedure", "class_dummy_handler.html#a05de1959c5f6b0781ae9b28684d665f9", null ],
    [ "SERIAL_TYPE", "class_dummy_handler.html#a6e648110dac4c805fd3596adc26a65c4", null ],
    [ "Timer_Queue", "class_dummy_handler.html#ad43dac0fe4f32a2939fea789ad61e763", null ],
    [ "AddDummy", "class_dummy_handler.html#a3cabe3d963351efb6674a3b4c24e5e5e", null ],
    [ "Close", "class_dummy_handler.html#a601116e6cf56c2999a3ae3f845eca2ef", null ],
    [ "CloseDummy", "class_dummy_handler.html#a3acb0f9e103c2b4d9a2684c8f6d0af4f", null ],
    [ "GetDummies", "class_dummy_handler.html#ae1bdcbbd9ac89f6aa474fc0a6363201d", null ],
    [ "GetIocpHandle", "class_dummy_handler.html#afea25b22d9cf2d65849b43cd6fdcaddf", null ],
    [ "GetSendOverlapExp", "class_dummy_handler.html#abb33552c53c5a1a07bd136d31eee4314", null ],
    [ "GetSerialForUseOverlapExp", "class_dummy_handler.html#a16fc46f95caac6c58a1fe9ec49cd8be0", null ],
    [ "GetTimerLock", "class_dummy_handler.html#ae79a148e535284fd04ab631806fef412", null ],
    [ "GetTimerQueue", "class_dummy_handler.html#a65d074c2f9b8bace6ef7f49fb5ce8d03", null ],
    [ "IsShutdown", "class_dummy_handler.html#ab09d78f592fb4abd63c0cf6af7b438a1", null ],
    [ "IsValidSerial", "class_dummy_handler.html#a9e4f39274c7cce39405abb693ee4f3f0", null ],
    [ "ProcessPacket", "class_dummy_handler.html#a7400d1663b5c2d7fd2553aadd2547632", null ],
    [ "ReturnUsedOverlapExp", "class_dummy_handler.html#a590c3c40275bee7b68438ad51714c10d", null ],
    [ "SendPacket", "class_dummy_handler.html#a4040788ee4352ac9dd07f4e700884e4c", null ],
    [ "SendRandomPacket", "class_dummy_handler.html#a5db24397b747633cef86822b2e557d5d", null ],
    [ "Start", "class_dummy_handler.html#a927bf3004cafb22ce170afc38f2cd8c2", null ]
];