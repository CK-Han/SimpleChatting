var struct_overlap___info =
[
    [ "Overlap_Info", "struct_overlap___info.html#a312477dcc1e3e0c10fdeff9e6673683b", null ],
    [ "PacketBuff", "struct_overlap___info.html#a3ae378d8d4c008d89bb7ea978f49ff9e", null ],
    [ "PacketSize", "struct_overlap___info.html#a50d1ad36f2193cb2a562591468c14d26", null ],
    [ "RecvOverlapExp", "struct_overlap___info.html#ad5f029631e6a2b31a55b74a27cf1490f", null ],
    [ "SavedPacketSize", "struct_overlap___info.html#acc7a9829d68aa8e0fd9e352727c12d50", null ]
];