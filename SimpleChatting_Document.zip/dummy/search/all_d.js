var searchData=
[
  ['wakeup_5ftime',['Wakeup_Time',['../struct_event___info.html#a48354c97153c9fe1708c7bbd40c28f01',1,'Event_Info']]],
  ['wsabuf',['WsaBuf',['../struct_overlap___exp.html#abc3a133d66ceafbfe65a914ea1702448',1,'Overlap_Exp']]]
];
