var searchData=
[
  ['max_5fdummy_5fcount',['MAX_DUMMY_COUNT',['../class_dummy_handler.html#aa5029c96b68074cf67c663ee4dd8a5c0',1,'DummyHandler']]],
  ['max_5foverlapexp_5fcount',['MAX_OVERLAPEXP_COUNT',['../class_dummy_handler.html#a389376d158b966fbdb39ce99e876bc14',1,'DummyHandler']]]
];
