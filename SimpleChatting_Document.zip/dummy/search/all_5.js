var searchData=
[
  ['iocp_5fbuffer',['Iocp_Buffer',['../struct_overlap___exp.html#a5a2366b2d80a8d60bef5ede47d0e281e',1,'Overlap_Exp']]],
  ['isshutdown',['IsShutdown',['../class_dummy_handler.html#ab09d78f592fb4abd63c0cf6af7b438a1',1,'DummyHandler']]],
  ['isvalidserial',['IsValidSerial',['../class_dummy_handler.html#a9e4f39274c7cce39405abb693ee4f3f0',1,'DummyHandler']]]
];
