var searchData=
[
  ['dummy',['Dummy',['../class_dummy.html',1,'']]],
  ['dummyhandler',['DummyHandler',['../class_dummy_handler.html',1,'']]]
];
