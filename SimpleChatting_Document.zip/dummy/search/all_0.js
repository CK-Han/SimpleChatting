var searchData=
[
  ['adddummy',['AddDummy',['../class_dummy_handler.html#a3cabe3d963351efb6674a3b4c24e5e5e',1,'DummyHandler']]]
];
