var searchData=
[
  ['serial_5ftype',['SERIAL_TYPE',['../class_dummy_handler.html#a6e648110dac4c805fd3596adc26a65c4',1,'DummyHandler']]]
];
