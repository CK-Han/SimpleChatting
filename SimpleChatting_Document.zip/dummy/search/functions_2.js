var searchData=
[
  ['dummy',['Dummy',['../class_dummy.html#afe03b8568b4af57481b092f8356ca041',1,'Dummy']]]
];
