var searchData=
[
  ['_7edummy',['~Dummy',['../class_dummy.html#a88fb47ca786c06692deb9602b1724ff3',1,'Dummy']]]
];
