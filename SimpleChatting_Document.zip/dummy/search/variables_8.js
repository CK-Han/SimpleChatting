var searchData=
[
  ['savedpacketsize',['SavedPacketSize',['../struct_overlap___info.html#acc7a9829d68aa8e0fd9e352727c12d50',1,'Overlap_Info']]],
  ['serial',['Serial',['../struct_overlap___exp.html#acbc561d6143a947adce940efea99c9e7',1,'Overlap_Exp::Serial()'],['../struct_event___info.html#afb8fbf39947712c031eb8cd404f80b32',1,'Event_Info::Serial()']]],
  ['serial_5ferror',['SERIAL_ERROR',['../class_dummy_handler.html#a68aa02bb858107901730f124aeb25d32',1,'DummyHandler']]],
  ['start_5fdummy_5fcount',['START_DUMMY_COUNT',['../class_dummy_handler.html#a5d61ece900aa6400eb089bed377d4b5f',1,'DummyHandler']]]
];
