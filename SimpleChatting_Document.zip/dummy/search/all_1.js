var searchData=
[
  ['close',['Close',['../class_dummy.html#a9678175ffc84c231e3a9343695b5c3cf',1,'Dummy::Close()'],['../class_dummy_handler.html#a601116e6cf56c2999a3ae3f845eca2ef',1,'DummyHandler::Close()']]],
  ['closedummy',['CloseDummy',['../class_dummy_handler.html#a3acb0f9e103c2b4d9a2684c8f6d0af4f',1,'DummyHandler']]],
  ['connect',['Connect',['../class_dummy.html#a4abda50c2d195b49a64e6f186da68809',1,'Dummy']]]
];
