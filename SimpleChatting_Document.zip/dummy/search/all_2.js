var searchData=
[
  ['dummy',['Dummy',['../class_dummy.html',1,'Dummy'],['../class_dummy.html#afe03b8568b4af57481b092f8356ca041',1,'Dummy::Dummy()']]],
  ['dummy_2ecpp',['Dummy.cpp',['../_dummy_8cpp.html',1,'']]],
  ['dummy_2eh',['Dummy.h',['../_dummy_8h.html',1,'']]],
  ['dummyhandler',['DummyHandler',['../class_dummy_handler.html',1,'DummyHandler'],['../class_dummy.html#a038c85874517442d4f012204e9c83ac2',1,'Dummy::DummyHandler()']]],
  ['dummyhandler_2ecpp',['DummyHandler.cpp',['../_dummy_handler_8cpp.html',1,'']]],
  ['dummyhandler_2eh',['DummyHandler.h',['../_dummy_handler_8h.html',1,'']]]
];
