var searchData=
[
  ['dummyhandler',['DummyHandler',['../class_dummy.html#a038c85874517442d4f012204e9c83ac2',1,'Dummy']]]
];
