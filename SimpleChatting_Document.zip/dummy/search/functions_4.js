var searchData=
[
  ['isshutdown',['IsShutdown',['../class_dummy_handler.html#ab09d78f592fb4abd63c0cf6af7b438a1',1,'DummyHandler']]],
  ['isvalidserial',['IsValidSerial',['../class_dummy_handler.html#a9e4f39274c7cce39405abb693ee4f3f0',1,'DummyHandler']]]
];
