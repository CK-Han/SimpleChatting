var searchData=
[
  ['getoverlap_5ftimeout_5fmilliseconds',['GETOVERLAP_TIMEOUT_MILLISECONDS',['../class_dummy_handler.html#a353fbf50fc22aed8cb030edfb1465f59',1,'DummyHandler']]],
  ['gqcs_5ftimeout_5fmilliseconds',['GQCS_TIMEOUT_MILLISECONDS',['../class_dummy_handler.html#a5ca22734581c02ff82c9317162f7763b',1,'DummyHandler']]]
];
