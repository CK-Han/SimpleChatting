var class_dummy =
[
    [ "Dummy", "class_dummy.html#afe03b8568b4af57481b092f8356ca041", null ],
    [ "~Dummy", "class_dummy.html#a88fb47ca786c06692deb9602b1724ff3", null ],
    [ "Close", "class_dummy.html#a9678175ffc84c231e3a9343695b5c3cf", null ],
    [ "Connect", "class_dummy.html#a4abda50c2d195b49a64e6f186da68809", null ],
    [ "GetLock", "class_dummy.html#a67cd0cc2ab4c162837996c66460d167c", null ],
    [ "GetSocket", "class_dummy.html#adc551bdc214276e8373e6fea43d85d66", null ],
    [ "DummyHandler", "class_dummy.html#a038c85874517442d4f012204e9c83ac2", null ]
];