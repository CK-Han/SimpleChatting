var class_event___compare =
[
    [ "operator()", "class_event___compare.html#a8da4ae554a971837ec6208de4c88e65d", null ]
];