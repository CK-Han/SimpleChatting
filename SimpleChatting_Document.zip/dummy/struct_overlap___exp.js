var struct_overlap___exp =
[
    [ "Overlap_Operation", "struct_overlap___exp.html#a5d55487c00c1a98350fa85b673fd8e81", [
      [ "OPERATION_RECV", "struct_overlap___exp.html#a5d55487c00c1a98350fa85b673fd8e81a1c40b8ade32f8e4a8f80d1c72f031718", null ],
      [ "OPERATION_SEND", "struct_overlap___exp.html#a5d55487c00c1a98350fa85b673fd8e81a66cee0a2379a9d17dfc1ce08fa6ce89a", null ],
      [ "OPERATION_RANDPACKET", "struct_overlap___exp.html#a5d55487c00c1a98350fa85b673fd8e81acabbe635d83b6604dcbe5b2f4d8ad5e4", null ]
    ] ],
    [ "Overlap_Exp", "struct_overlap___exp.html#aa6de150c290c1c335cf11df5af534824", null ],
    [ "Iocp_Buffer", "struct_overlap___exp.html#a5a2366b2d80a8d60bef5ede47d0e281e", null ],
    [ "Operation", "struct_overlap___exp.html#aae39abc7deb520d6197a72ecde83142a", null ],
    [ "Original_Overlap", "struct_overlap___exp.html#a123e872cd031b84169fc59e4e8a89bd4", null ],
    [ "Serial", "struct_overlap___exp.html#acbc561d6143a947adce940efea99c9e7", null ],
    [ "WsaBuf", "struct_overlap___exp.html#abc3a133d66ceafbfe65a914ea1702448", null ]
];