var struct_event___info =
[
    [ "Event_Type", "struct_event___info.html#a0d328d85554aec8932a3d1dde87d45d5", null ],
    [ "Serial", "struct_event___info.html#afb8fbf39947712c031eb8cd404f80b32", null ],
    [ "Wakeup_Time", "struct_event___info.html#a48354c97153c9fe1708c7bbd40c28f01", null ]
];