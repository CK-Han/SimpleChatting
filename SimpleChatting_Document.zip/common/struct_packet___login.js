var struct_packet___login =
[
    [ "Deserialize", "struct_packet___login.html#aca47d44b2a342e3f524aa7cff558a355", null ],
    [ "Serialize", "struct_packet___login.html#ab7098d5b3aa5a8905ab8ca9a7a816592", null ],
    [ "isCreated", "struct_packet___login.html#a821e9a5c7b13bfdbf5aa5895058389a3", null ],
    [ "userName", "struct_packet___login.html#a83cfba72204a5e1ce790c5e051d171f2", null ]
];