var class_packet___base_1_1_type_adder =
[
    [ "TypeAdder", "class_packet___base_1_1_type_adder.html#a2b1e48b0e0afde8bac34949c43919017", null ],
    [ "GetType", "class_packet___base_1_1_type_adder.html#a2365294da773b5f69343e33064d07ddb", null ]
];