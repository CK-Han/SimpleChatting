var struct_packet___channel___list =
[
    [ "Deserialize", "struct_packet___channel___list.html#ad2857248459090c71a154c434a585144", null ],
    [ "Serialize", "struct_packet___channel___list.html#a0901a8fcef646c0189acaf871cf59820", null ],
    [ "customChannelCount", "struct_packet___channel___list.html#a78b4f375d8f9b2416376028a2f325d18", null ],
    [ "publicChannelNames", "struct_packet___channel___list.html#a6bf79b28d5acc165f95edc556df48995", null ]
];