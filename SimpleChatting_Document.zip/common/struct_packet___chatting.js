var struct_packet___chatting =
[
    [ "Deserialize", "struct_packet___chatting.html#a15d19817d2950e819fbdab7bb0c614fe", null ],
    [ "Serialize", "struct_packet___chatting.html#a339acf2c81d5b56788565e42918ca16a", null ],
    [ "chat", "struct_packet___chatting.html#a646f69e3231e20952333082ed7f6169c", null ],
    [ "isWhisper", "struct_packet___chatting.html#ad219d58c2addb6d2c1316f034cc4c97f", null ],
    [ "listener", "struct_packet___chatting.html#a66246c19218c4e10aa9d00e94a8f020c", null ],
    [ "talker", "struct_packet___chatting.html#a92a12be78b5b8f816498d3f0b9f93589", null ]
];