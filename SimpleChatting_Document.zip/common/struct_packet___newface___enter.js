var struct_packet___newface___enter =
[
    [ "Deserialize", "struct_packet___newface___enter.html#a18a6e78493965c93a8a7e6ceec9137ba", null ],
    [ "Serialize", "struct_packet___newface___enter.html#a640c085b8056a4337ef16608bba5f618", null ],
    [ "userName", "struct_packet___newface___enter.html#a22a3ac9e8e789652af4f1fe71c1ed678", null ]
];