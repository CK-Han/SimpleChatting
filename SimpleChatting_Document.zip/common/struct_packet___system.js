var struct_packet___system =
[
    [ "Deserialize", "struct_packet___system.html#a49fa78321090ca4799a2e207ea08331b", null ],
    [ "Serialize", "struct_packet___system.html#a642795279eb5ce0c2f8497f40da21e12", null ],
    [ "systemMessage", "struct_packet___system.html#af4f61651397ad60bf8f95d2571c4ae25", null ]
];