var searchData=
[
  ['systemmessage',['systemMessage',['../struct_packet___system.html#af4f61651397ad60bf8f95d2571c4ae25',1,'Packet_System']]]
];
