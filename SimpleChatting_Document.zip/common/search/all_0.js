var searchData=
[
  ['channelmaster',['channelMaster',['../struct_packet___channel___enter.html#a01399c5e32bea1c06cc2f7f71d7ab2b7',1,'Packet_Channel_Enter']]],
  ['channelname',['channelName',['../struct_packet___channel___enter.html#a9b9427d2abf1c1a7db2b8864b28c80da',1,'Packet_Channel_Enter::channelName()'],['../struct_packet___channel___users.html#a48e78550acf5ff788762ad3c9bc240fe',1,'Packet_Channel_Users::channelName()'],['../struct_packet___kick___user.html#afb844972f2767423f02064be285b10ab',1,'Packet_Kick_User::channelName()'],['../struct_packet___new___master.html#a65417b9da8b15103848207613182b97b',1,'Packet_New_Master::channelName()']]],
  ['chat',['chat',['../struct_packet___chatting.html#a646f69e3231e20952333082ed7f6169c',1,'Packet_Chatting']]],
  ['customchannelcount',['customChannelCount',['../struct_packet___channel___list.html#a78b4f375d8f9b2416376028a2f325d18',1,'Packet_Channel_List']]]
];
