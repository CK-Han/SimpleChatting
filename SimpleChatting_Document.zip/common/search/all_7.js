var searchData=
[
  ['master',['master',['../struct_packet___new___master.html#a20fbf429e4634e5b41f3f05434d12103',1,'Packet_New_Master']]],
  ['max_5fbuf_5fsize',['MAX_BUF_SIZE',['../class_packet___base.html#a3993dc816fd15ff8a2c8bfacf0b3a05a',1,'Packet_Base']]],
  ['max_5fchannelname_5fsize',['MAX_CHANNELNAME_SIZE',['../class_packet___base.html#afa1a1645c36e05c95ec136e5063657bd',1,'Packet_Base']]],
  ['max_5fmessage_5fsize',['MAX_MESSAGE_SIZE',['../class_packet___base.html#a84488f11d2968803f105d47f80da1b71',1,'Packet_Base']]],
  ['max_5fusername_5fsize',['MAX_USERNAME_SIZE',['../class_packet___base.html#a1faf4dc87c33a24cb00c9cd5a350f4b5',1,'Packet_Base']]]
];
