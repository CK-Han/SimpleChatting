var searchData=
[
  ['invalidstreamargument',['InvalidStreamArgument',['../class_stream_base_1_1_invalid_stream_argument.html',1,'StreamBase::InvalidStreamArgument'],['../class_stream_base_1_1_invalid_stream_argument.html#a9d86b58c4c0deabc50ab0935f8604f96',1,'StreamBase::InvalidStreamArgument::InvalidStreamArgument()']]],
  ['iscreated',['isCreated',['../struct_packet___login.html#a821e9a5c7b13bfdbf5aa5895058389a3',1,'Packet_Login']]],
  ['iskicked',['isKicked',['../struct_packet___user___leave.html#a6a67e8ad3f7cb2cae0a06f44463e6f6f',1,'Packet_User_Leave']]],
  ['iswhisper',['isWhisper',['../struct_packet___chatting.html#ad219d58c2addb6d2c1316f034cc4c97f',1,'Packet_Chatting']]]
];
