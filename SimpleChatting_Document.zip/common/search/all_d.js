var searchData=
[
  ['username',['userName',['../struct_packet___login.html#a83cfba72204a5e1ce790c5e051d171f2',1,'Packet_Login::userName()'],['../struct_packet___newface___enter.html#a22a3ac9e8e789652af4f1fe71c1ed678',1,'Packet_Newface_Enter::userName()'],['../struct_packet___user___leave.html#aca24f91122e3af5e2745a05a85835753',1,'Packet_User_Leave::userName()']]],
  ['usernames',['userNames',['../struct_packet___channel___users.html#ad7b7d6dfdf0754873f2390ecc61ef136',1,'Packet_Channel_Users']]]
];
