var indexSectionsWithContent =
{
  0: "cdghiklmoprstuvw~",
  1: "ipst",
  2: "ps",
  3: "dgiorstw~",
  4: "ciklmpstu",
  5: "hsv",
  6: "t"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "typedefs",
  6: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Typedefs",
  6: "Pages"
};

