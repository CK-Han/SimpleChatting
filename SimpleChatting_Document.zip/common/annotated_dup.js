var annotated_dup =
[
    [ "Packet_Base", "class_packet___base.html", "class_packet___base" ],
    [ "Packet_Channel_Enter", "struct_packet___channel___enter.html", "struct_packet___channel___enter" ],
    [ "Packet_Channel_List", "struct_packet___channel___list.html", "struct_packet___channel___list" ],
    [ "Packet_Channel_Users", "struct_packet___channel___users.html", "struct_packet___channel___users" ],
    [ "Packet_Chatting", "struct_packet___chatting.html", "struct_packet___chatting" ],
    [ "Packet_Kick_User", "struct_packet___kick___user.html", "struct_packet___kick___user" ],
    [ "Packet_Login", "struct_packet___login.html", "struct_packet___login" ],
    [ "Packet_New_Master", "struct_packet___new___master.html", "struct_packet___new___master" ],
    [ "Packet_Newface_Enter", "struct_packet___newface___enter.html", "struct_packet___newface___enter" ],
    [ "Packet_System", "struct_packet___system.html", "struct_packet___system" ],
    [ "Packet_User_Leave", "struct_packet___user___leave.html", "struct_packet___user___leave" ],
    [ "StreamBase", "class_stream_base.html", "class_stream_base" ],
    [ "StreamReader", "class_stream_reader.html", "class_stream_reader" ],
    [ "StreamWriter", "class_stream_writer.html", "class_stream_writer" ]
];