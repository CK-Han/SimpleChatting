var class_stream_reader_1_1_stream_read_underflow =
[
    [ "StreamReadUnderflow", "class_stream_reader_1_1_stream_read_underflow.html#adc4902b5bc8a45ee40adb981b161f715", null ]
];