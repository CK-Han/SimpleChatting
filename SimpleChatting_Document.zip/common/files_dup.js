var files_dup =
[
    [ "protocol.cpp", "protocol_8cpp.html", "protocol_8cpp" ],
    [ "protocol.h", "protocol_8h.html", "protocol_8h" ],
    [ "stream.cpp", "stream_8cpp.html", null ],
    [ "stream.h", "stream_8h.html", [
      [ "StreamBase", "class_stream_base.html", "class_stream_base" ],
      [ "InvalidStreamArgument", "class_stream_base_1_1_invalid_stream_argument.html", "class_stream_base_1_1_invalid_stream_argument" ],
      [ "StreamWriter", "class_stream_writer.html", "class_stream_writer" ],
      [ "StreamWriteOverflow", "class_stream_writer_1_1_stream_write_overflow.html", "class_stream_writer_1_1_stream_write_overflow" ],
      [ "StreamReader", "class_stream_reader.html", "class_stream_reader" ],
      [ "StreamReadUnderflow", "class_stream_reader_1_1_stream_read_underflow.html", "class_stream_reader_1_1_stream_read_underflow" ]
    ] ]
];