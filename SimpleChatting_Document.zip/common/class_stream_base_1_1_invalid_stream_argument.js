var class_stream_base_1_1_invalid_stream_argument =
[
    [ "InvalidStreamArgument", "class_stream_base_1_1_invalid_stream_argument.html#a9d86b58c4c0deabc50ab0935f8604f96", null ]
];