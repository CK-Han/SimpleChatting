var struct_packet___channel___enter =
[
    [ "Deserialize", "struct_packet___channel___enter.html#a673c3d4398bfa88cd78622a2403e0546", null ],
    [ "Serialize", "struct_packet___channel___enter.html#ac295efd900ac5126d5e26b08d259126c", null ],
    [ "channelMaster", "struct_packet___channel___enter.html#a01399c5e32bea1c06cc2f7f71d7ab2b7", null ],
    [ "channelName", "struct_packet___channel___enter.html#a9b9427d2abf1c1a7db2b8864b28c80da", null ]
];