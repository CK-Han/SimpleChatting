var hierarchy =
[
    [ "invalid_argument", null, [
      [ "StreamBase::InvalidStreamArgument", "class_stream_base_1_1_invalid_stream_argument.html", null ]
    ] ],
    [ "overflow_error", null, [
      [ "StreamWriter::StreamWriteOverflow", "class_stream_writer_1_1_stream_write_overflow.html", null ]
    ] ],
    [ "Packet_Base", "class_packet___base.html", [
      [ "Packet_Channel_Enter", "struct_packet___channel___enter.html", null ],
      [ "Packet_Channel_List", "struct_packet___channel___list.html", null ],
      [ "Packet_Channel_Users", "struct_packet___channel___users.html", null ],
      [ "Packet_Chatting", "struct_packet___chatting.html", null ],
      [ "Packet_Kick_User", "struct_packet___kick___user.html", null ],
      [ "Packet_Login", "struct_packet___login.html", null ],
      [ "Packet_New_Master", "struct_packet___new___master.html", null ],
      [ "Packet_Newface_Enter", "struct_packet___newface___enter.html", null ],
      [ "Packet_System", "struct_packet___system.html", null ],
      [ "Packet_User_Leave", "struct_packet___user___leave.html", null ]
    ] ],
    [ "StreamBase", "class_stream_base.html", [
      [ "StreamReader", "class_stream_reader.html", null ],
      [ "StreamWriter", "class_stream_writer.html", null ]
    ] ],
    [ "Packet_Base::TypeAdder", "class_packet___base_1_1_type_adder.html", null ],
    [ "underflow_error", null, [
      [ "StreamReader::StreamReadUnderflow", "class_stream_reader_1_1_stream_read_underflow.html", null ]
    ] ]
];