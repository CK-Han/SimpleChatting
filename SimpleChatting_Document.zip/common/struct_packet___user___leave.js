var struct_packet___user___leave =
[
    [ "Deserialize", "struct_packet___user___leave.html#a72d720476c2bb6bba8ef3cd5e02fdc10", null ],
    [ "Serialize", "struct_packet___user___leave.html#a43cd48ea6e7192d6a35a6c03a39cde7f", null ],
    [ "isKicked", "struct_packet___user___leave.html#a6a67e8ad3f7cb2cae0a06f44463e6f6f", null ],
    [ "userName", "struct_packet___user___leave.html#aca24f91122e3af5e2745a05a85835753", null ]
];