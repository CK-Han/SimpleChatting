var protocol_8h =
[
    [ "Packet_Base", "class_packet___base.html", "class_packet___base" ],
    [ "TypeAdder", "class_packet___base_1_1_type_adder.html", "class_packet___base_1_1_type_adder" ],
    [ "Packet_System", "struct_packet___system.html", "struct_packet___system" ],
    [ "Packet_Login", "struct_packet___login.html", "struct_packet___login" ],
    [ "Packet_Channel_List", "struct_packet___channel___list.html", "struct_packet___channel___list" ],
    [ "Packet_Channel_Enter", "struct_packet___channel___enter.html", "struct_packet___channel___enter" ],
    [ "Packet_Channel_Users", "struct_packet___channel___users.html", "struct_packet___channel___users" ],
    [ "Packet_Newface_Enter", "struct_packet___newface___enter.html", "struct_packet___newface___enter" ],
    [ "Packet_User_Leave", "struct_packet___user___leave.html", "struct_packet___user___leave" ],
    [ "Packet_Kick_User", "struct_packet___kick___user.html", "struct_packet___kick___user" ],
    [ "Packet_Chatting", "struct_packet___chatting.html", "struct_packet___chatting" ],
    [ "Packet_New_Master", "struct_packet___new___master.html", "struct_packet___new___master" ],
    [ "GetPacketSize", "protocol_8h.html#a340a591038b6a8781167be79f4e89bc3", null ],
    [ "GetPacketType", "protocol_8h.html#a4941f826d7935b89b0e55e9e8bf7c0a7", null ]
];