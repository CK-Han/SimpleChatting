var class_stream_base =
[
    [ "InvalidStreamArgument", "class_stream_base_1_1_invalid_stream_argument.html", "class_stream_base_1_1_invalid_stream_argument" ],
    [ "SizeType", "class_stream_base.html#a295061bb364a87fe3e39c5c572e8832c", null ]
];