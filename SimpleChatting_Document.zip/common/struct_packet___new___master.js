var struct_packet___new___master =
[
    [ "Deserialize", "struct_packet___new___master.html#a217ddade594a273017df896db0425796", null ],
    [ "Serialize", "struct_packet___new___master.html#a7c10978ac9e7c15c7e845efd28e18380", null ],
    [ "channelName", "struct_packet___new___master.html#a65417b9da8b15103848207613182b97b", null ],
    [ "master", "struct_packet___new___master.html#a20fbf429e4634e5b41f3f05434d12103", null ]
];