var struct_packet___channel___users =
[
    [ "Deserialize", "struct_packet___channel___users.html#ae8332dfa9f483104226c6697d5006d94", null ],
    [ "Serialize", "struct_packet___channel___users.html#ae0a00f6dbc3c7e4fb5bde6b9f0fdb252", null ],
    [ "channelName", "struct_packet___channel___users.html#a48e78550acf5ff788762ad3c9bc240fe", null ],
    [ "userNames", "struct_packet___channel___users.html#ad7b7d6dfdf0754873f2390ecc61ef136", null ]
];