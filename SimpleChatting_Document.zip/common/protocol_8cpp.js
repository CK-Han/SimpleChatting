var protocol_8cpp =
[
    [ "GetPacketSize", "protocol_8cpp.html#a340a591038b6a8781167be79f4e89bc3", null ],
    [ "GetPacketType", "protocol_8cpp.html#a4941f826d7935b89b0e55e9e8bf7c0a7", null ]
];