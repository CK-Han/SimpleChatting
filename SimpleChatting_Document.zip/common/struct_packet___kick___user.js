var struct_packet___kick___user =
[
    [ "Deserialize", "struct_packet___kick___user.html#ac643d8de401819f05b0935997e0bbb75", null ],
    [ "Serialize", "struct_packet___kick___user.html#ad4b60401567f2b1e5bd9dad9692531b9", null ],
    [ "channelName", "struct_packet___kick___user.html#afb844972f2767423f02064be285b10ab", null ],
    [ "kicker", "struct_packet___kick___user.html#a25b80ba800a566322f11dfe3d0d128e2", null ],
    [ "target", "struct_packet___kick___user.html#a8203128900a757eba0beefb55036ce7a", null ]
];